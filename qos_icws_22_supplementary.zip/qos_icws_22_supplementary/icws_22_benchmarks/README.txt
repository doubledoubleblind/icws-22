Each domain:
	- Domain file: domain.pddl
	- Generated instance: gen-instances
	- Reformulated instance: re-instances, domain-{x}.pddl and instance-{x}.pddl