# DriverLog (Numeric, For Automatic Planners)

## Domain Description

This domain involves driving trucks around delivering packages between locations.
The complication is that the trucks require drivers who must walk between trucks in order to drive them.
The paths for walking and the roads for driving form different maps on the locations.

## Authors

*unknown*

## Original File Names

| file             | original name         |
|------------------|-----------------------|
| domain.pddl      | driverlogNumeric.pddl |
| instance-1.pddl  | pfile1                |
| instance-2.pddl  | pfile2                |
| instance-3.pddl  | pfile3                |
| instance-4.pddl  | pfile4                |
| instance-5.pddl  | pfile5                |
| instance-6.pddl  | pfile6                |
| instance-7.pddl  | pfile7                |
| instance-8.pddl  | pfile8                |
| instance-9.pddl  | pfile9                |
| instance-10.pddl | pfile10               |
| instance-11.pddl | pfile11               |
| instance-12.pddl | pfile12               |
| instance-13.pddl | pfile13               |
| instance-14.pddl | pfile14               |
| instance-15.pddl | pfile15               |
| instance-16.pddl | pfile16               |
| instance-17.pddl | pfile17               |
| instance-18.pddl | pfile18               |
| instance-19.pddl | pfile19               |
| instance-20.pddl | pfile20               |
