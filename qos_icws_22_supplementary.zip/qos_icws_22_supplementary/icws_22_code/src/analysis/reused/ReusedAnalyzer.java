package analysis.reused;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import analysis.DomainAnalyzer;
import analysis.domain.service.Provider;
import analysis.domain.service.grounding.GroundedFunct;
import analysis.domain.service.grounding.GroundedService;
import analysis.domain.service.obj.Obj;

public class ReusedAnalyzer {

	public static Map<String, Set<Obj>> analyze(GroundedFunct p, Set<GroundedService> consideredServices) {
//		System.out.println(DomainAnalyzer.unchangableProps);
		Map<Provider, Integer> lastUsedMap = new HashMap<>();
		Map<Provider, Integer> firstUsedMap = new HashMap<>();
		Map<Provider, Integer> lastArgMap = new HashMap<>();
		Map<Provider, Set<GroundedService>> serviceProvisonMap = new HashMap<>();
		Set<Provider> allProviders = DomainAnalyzer.extractProviders(consideredServices);

		for (Provider provider : allProviders) {
			int lastUse = findLastUse(provider, consideredServices);
			int firstUse = findFirstUse(provider, consideredServices);
			int lastArg = findLastArg(provider, consideredServices);
			Set<GroundedService> providedServices = DomainAnalyzer.findProvidedServices(provider, consideredServices);
			serviceProvisonMap.put(provider, providedServices);
			lastUsedMap.put(provider, lastUse);
			firstUsedMap.put(provider, firstUse);
			lastArgMap.put(provider, lastArg);
		}

//		for (Provider provider : lastUsedMap.keySet()) {
//			System.out.println(provider + "-->" + firstUsedMap.get(provider) + "***" + lastUsedMap.get(provider) + "***"
//					+ lastArgMap.get(provider));
//		}
//		System.out.println("----------------");

		Map<String, Set<Obj>> providersMap = DomainAnalyzer.computeProviders();

		for (Provider provider : allProviders) {
			Provider replacingProvider = findReplacingProvider(provider, allProviders, firstUsedMap, lastUsedMap,
					lastArgMap, DomainAnalyzer.unchangableProps, serviceProvisonMap);
			if (replacingProvider != null) {
//				System.out.println(provider + "<<<<" + replacingProvider);
				Set<Obj> ps = providersMap.get(provider.type);
				ps.remove(provider);
				providersMap.put(provider.type, ps);
			}
		}
		return providersMap;
	}

	private static int findLastArg(Provider provider, Set<GroundedService> consideredServices) {
		int result = 0;
		for (GroundedService s : consideredServices) {
			if (!s.provider.equals(provider) && s.arguments.contains(provider) && s.getIndex() > result)
				result = s.getIndex();
		}
		return result;
	}

	private static int findFirstUse(Provider provider, Set<GroundedService> consideredServices) {
		int result = 10000;
		for (GroundedService s : consideredServices) {
			if (s.provider.equals(provider) && s.getIndex() < result)
				result = s.getIndex();
		}
		return result;
	}

	private static Provider findReplacingProvider(Provider provider, Set<Provider> allProviders,
			Map<Provider, Integer> firstUsedMap, Map<Provider, Integer> lastUsedMap, Map<Provider, Integer> lastArgMap,
			Set<GroundedFunct> unchangableProps, Map<Provider, Set<GroundedService>> serviceProvisonMap) {
		for (Provider p : allProviders) {
			if (p.type.equals(provider.type) && firstUsedMap.get(provider) > lastUsedMap.get(p)
					&& firstUsedMap.get(provider) > lastArgMap.get(p)// Optional
					&& canBeReplacable(provider, p, unchangableProps, serviceProvisonMap)) {
				return p;
			}
		}
		return null;
	}

	private static boolean canBeReplacable(Provider p1, Provider p2, Set<GroundedFunct> unchangableProps,
			Map<Provider, Set<GroundedService>> serviceProvisonMap) {
		if (!p2.type.equals(p1.type))
			return false;
		Set<GroundedFunct> precondsP1 = new HashSet<>();
		for (GroundedService s : serviceProvisonMap.get(p1)) {
			// TODO: Consider the numeric props, consider only =, not > and <
			precondsP1.addAll(s.preconds);
		}
		for (GroundedFunct p : precondsP1) {
			if (unchangableProps.contains(p))
				return false;
		}
		return true;
	}

	private static int findLastUse(Provider provider, Set<GroundedService> consideredServices) {
		int result = 0;
		for (GroundedService s : consideredServices) {
			if (s.provider.equals(provider) && s.getIndex() > result)
				result = s.getIndex();
		}
		return result;
	}

}
