package analysis.restriction;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import analysis.domain.service.obj.Obj;

public class ObjectPropValues {
	Obj provider;
	private Set<String> allPossibleProps;
	boolean isUnchanged = false;
	List<String> ignoredProps;

	public ObjectPropValues(Obj provider, Set<String> initRelatedProps, List<String> ignoredProps) {
		this.provider = provider;
		allPossibleProps = new HashSet<>();
		this.ignoredProps = ignoredProps;
		for (String i : initRelatedProps) {
			if (!isIgnored(i)) {
				this.allPossibleProps.add(i);
			}
		}
	}

	private boolean isIgnored(String i) {
		for (String ig : ignoredProps) {
			if (i.contains("(" + ig + " "))
				return true;
		}
		return false;
	}

	public ObjectPropValues(Obj provider, Set<String> init) {
		this.provider = provider;
		allPossibleProps = new HashSet<>(init);
	}

	public void addPropVal(String prop) {
		int before = allPossibleProps.size();
		this.allPossibleProps.add(prop);
		isUnchanged = (before == allPossibleProps.size());
	}

	public void addPropVals(Set<String> props) {
		int before = allPossibleProps.size();
		this.allPossibleProps.addAll(props);
		isUnchanged = (before == allPossibleProps.size());
	}

	public boolean isUnchanged() {
		return isUnchanged;
	}

	public Set<String> getAllPossibleProps() {
		return allPossibleProps;
	}

	public Obj getProvider() {
		return provider;
	}

}
