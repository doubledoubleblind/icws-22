package analysis.restriction;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import analysis.ProblemParser;
import analysis.domain.service.Predicate;
import analysis.domain.service.Service;
import analysis.domain.service.grounding.GroundedFunct;
import analysis.domain.service.grounding.GroundedPredicate;
import analysis.domain.service.grounding.GroundedService;
import analysis.domain.service.grounding.Grounder;
import analysis.domain.service.obj.Obj;

public class FastRestrictionAnalyzer {

	public static ObjectPropValues expand(ObjectPropValues opv, List<Service> services, Set<String> inits,
			List<ObjectPropValues> opvs, Map<String, Set<Obj>> objs_map, Set<String> unchangablePredNames,
			Set<String> unchangableFacts) {
		for (Service service : services) {
			if (service.provider.type.equals(opv.getProvider().type)) {
				Service temp = applyIgnorance(service, opv.ignoredProps);
//				System.out.println(temp);
				Set<GroundedService> gss = tryToGround(temp, opv, inits, opvs, objs_map, unchangablePredNames,
						unchangableFacts);
				if (gss != null) {
					for (GroundedService gs : gss) {
						Set<String> relatedProps = computeRelatedProps(gs.pEffects, opv.provider);
						opv.addPropVals(relatedProps);
					}
				}
			}
		}
		return opv;
	}

	private static Service applyIgnorance(Service service, List<String> ignoredProps) {
		Service temp = new Service(service);
		for (String ig : ignoredProps) {
			List<Predicate> preconds = new ArrayList<>();
			List<Predicate> pEffects = new ArrayList<>();
			for (Predicate pred : temp.preconds) {
				if (!pred.name.equals(ig))
					preconds.add(pred);
			}
			for (Predicate pred : temp.pEffects) {
				if (!pred.name.equals(ig))
					pEffects.add(pred);
			}
			temp.preconds = preconds;
			temp.pEffects = pEffects;
		}
		return temp;
	}

	private static Set<String> computeRelatedProps(List<GroundedPredicate> pEffects, Obj provider) {
		Set<String> result = new HashSet<>();
		for (GroundedPredicate e : pEffects) {
			if (e.arguments.contains(provider))
				result.add(e.toPDDL());
		}
		return result;
	}

	private static Set<GroundedService> tryToGround(Service service, ObjectPropValues opv, Set<String> inits,
			List<ObjectPropValues> opvs, Map<String, Set<Obj>> objs_map, Set<String> unchangablePredNames,
			Set<String> unchangableFacts) {
		Set<Obj> allObjs = new HashSet<>();
		for (String type : objs_map.keySet())
			allObjs.addAll(objs_map.get(type));

		Set<GroundedService> result = new HashSet<>();
//		System.out.println("-->" + opv.provider);
//		System.out.println(service);
//		System.out.println("---------------");

		for (int i = 0; i < service.preconds.size(); i++) {
			Predicate pred = service.preconds.get(i);
			Set<String> correspondingProp = findPropByName(pred.name, opv.getAllPossibleProps());
			for (String prop : correspondingProp) {
//				System.out.println(prop);
				GroundedFunct gf = ProblemParser.parseProposition(prop, allObjs);
				List<Obj> args = gf.arguments;
//				System.out.println(args);

				Set<GroundedService> gss = Grounder.groundByInits(service, gf, objs_map, pred, unchangablePredNames,
						unchangableFacts, opv);
				result.addAll(gss);
//				System.out.println("__________________________");

//				GroundedService gs = new GroundedService((Provider) opv.getProvider().toProvider(), service.name);
//				gs.setSymbolicService(service);
//				result.add(gs);
			}
		}
		return result;
	}

	private static Set<String> findPropByName(String name, Set<String> allPossibleProps) {
		Set<String> result = new HashSet<>();
		for (String prop : allPossibleProps) {
			if (prop.contains("(" + name + " "))
				result.add(prop);
		}
		return result;
	}

	private static boolean isFixedPoint(List<ObjectPropValues> opvs) {
		for (ObjectPropValues opv : opvs) {
			if (!opv.isUnchanged())
				return false;
		}
		return true;
	}

	private static Set<String> extractProviderTypes(List<Service> services) {
		Set<String> result = new HashSet<>();
		for (Service s : services) {
			result.add(s.provider.type);
		}
		return result;
	}
}
