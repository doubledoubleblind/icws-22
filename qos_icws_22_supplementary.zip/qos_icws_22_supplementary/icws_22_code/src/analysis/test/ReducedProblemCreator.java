package analysis.test;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import analysis.Config;
import analysis.DomainAnalyzer;
import analysis.DomainParser;
import analysis.Preprocessor;
import analysis.ProblemParser;
import analysis.domain.service.Predicate;
import analysis.domain.service.Service;
import analysis.domain.service.grounding.GroundedFunct;
import analysis.domain.service.grounding.Grounder;
import analysis.domain.service.obj.Obj;
import analysis.reused.ReusedAnalyzer;
import analysis.utils.Utils;

public class ReducedProblemCreator {
	public static String AVAILBLE_PROP_PREFIX = "ss-avail";
	public static String SELECTING_ACT_PREFIX = "ss-selecting";

	public static void main(String[] args) {
		boolean simplified = Config.SIMPLIFY;
		String benchmark = "";
		String domainName = "";
		benchmark = "../benchmark-2/depots-numeric-automatic";
		domainName = "Depot";

		Map<String, Set<String>> isARelations = DomainParser.parseTypes(benchmark + "/domain.pddl");
		List<Service> services = DomainParser.parseFile(benchmark + "/domain.pddl");
		if (simplified)
			services = Preprocessor.simplify(services);

		for (int i = 0; i < 20; i++) {
			long start = System.currentTimeMillis();
			String prob = Utils.readPDDL(benchmark + "/gen-instances/instance-" + i + ".pddl");
			Map<String, Set<Obj>> objs_map = ProblemParser.parseObjs(prob);
			List<Predicate> goals = ProblemParser.extractGoalPredicates(prob, objs_map);
			System.out.println("instance-" + i + ", #GOALS: " + goals.size());
			Map<String, Set<Obj>> requiredProvidersMap = new HashMap<String, Set<Obj>>();
			for (Predicate pred : goals) {
				GroundedFunct p = Grounder.symbolicFunctGrounding(pred);
				DomainAnalyzer.analyze(services, p, Config.MAX_DETH, objs_map, null, isARelations);
				Map<String, Set<Obj>> providersMap = DomainAnalyzer.computeProviders();

				if (Config.DEBUG) {
					System.out.println("........BEFORE REUSED........");
					for (String type : providersMap.keySet())
						System.out.println(type + "---" + providersMap.get(type).size());
				}
				if (Config.REUSED) {
					providersMap = ReusedAnalyzer.analyze(p, DomainAnalyzer.getConsideredServices());
					if (Config.DEBUG) {
						System.out.println("........AFTER REUSED........");
						for (String type : providersMap.keySet())
							System.out.println(type + "---" + providersMap.get(type).size());
					}
				}
				requiredProvidersMap = mergeProviderMap(requiredProvidersMap, providersMap);
				DomainAnalyzer.reset();
			}
			if (Config.REUSED) {
				System.out.println("........FINAL........");
				for (String type : requiredProvidersMap.keySet())
					if (objs_map.get(type) != null)
						System.out.println(type + "---" + objs_map.get(type).size() + "-->"
								+ requiredProvidersMap.get(type).size());
			}
			System.out.println("-----------------------------");
			constructReducedProb(benchmark, services, i, objs_map, requiredProvidersMap, domainName);
			System.out.println((System.currentTimeMillis() - start)/1000.0);
			break;
		}
	}

	private static Set<String> findUnchangableTypes(Map<String, Set<Obj>> requiredProvidersMap) {
		Set<String> results = new HashSet<>();
		for (String t : requiredProvidersMap.keySet()) {
			if (t.indexOf("*") > 0) {
				String[] parts = t.split("\\*");
				results.add(parts[0]);
				results.add(t);
			}
		}
		return results;
	}

	private static void constructReducedProb(String benchmark, List<Service> services, int i,
			Map<String, Set<Obj>> objs_map, Map<String, Set<Obj>> requiredProvidersMap, String domainName) {
		String probPath = benchmark + "/gen-instances/instance-" + i + ".pddl";
		File genInstancesDir = new File(benchmark + "/re-instances");
		if (!genInstancesDir.exists())
			genInstancesDir.mkdir();

		// 0. Postprocess the required map
		Set<String> unchangableTypes = findUnchangableTypes(requiredProvidersMap);
		for (String t : unchangableTypes)
			requiredProvidersMap.remove(t);

		// 1. Create new problem from old one
		// - Remove all providers
		Set<String> providerTypes = new HashSet<>();
		for (Service s : services) {
			if (unchangableTypes.contains(s.provider.type)) {
				// TODO Ignore for now
			} else
				providerTypes.add(s.provider.type);

		}
//		providerTypes.remove("driver");

		Set<Obj> removedPoviders = new HashSet<>();
		for (String type : providerTypes) {
			// TODO: child type
			Set<Obj> givenObjs = objs_map.get(type);
			Set<Obj> requiredObjs = requiredProvidersMap.get(type);
			if (requiredObjs == null || requiredObjs.size() < givenObjs.size()) {
				removedPoviders.addAll(givenObjs);
				objs_map.remove(type);
			} else { // requiredObjs.size() >= givenObjs.size()
				// Keep the same, not consider in requiredProvidersMap
				requiredProvidersMap.remove(type);
			}
		}

		System.out.println(requiredProvidersMap);

//		// - Remove related props
		String probPDDL = Utils.read(probPath);
		Map<Obj, Set<String>> relatedPropOfRemovedProviders = new HashMap<>();
		Set<String> inits = ProblemParser.parseInit(probPDDL);

		/*
		 * This map is to store numeric properties Assign doesn't work, so use increase,
		 * then for numeric prop, need to initiate the prop = 0 for required provider
		 */
		Map<String, Set<String>> numericPropsMap = new HashMap<>();

		for (Obj provider : removedPoviders) {
			Set<String> relatedProps = computeRelatedProps(inits, provider);
			relatedPropOfRemovedProviders.put(provider, relatedProps);
//			System.out.println(provider);
//			System.out.println(relatedProps);
//			System.out.println("-------");
			inits.removeAll(relatedProps);

			// Find numeric props generate template
			Set<String> numericProps = numericPropsMap.get(provider.type);
			if (numericProps == null) {
				numericProps = new HashSet<>();
				for (String prop : relatedProps) {
					String p = prop.trim();
					if (p.startsWith("(= ")) {
						p = generateNumPropTemp(p, provider);
						numericProps.add(p);
					}
				}
				numericPropsMap.put(provider.type, numericProps);
			}
		}

		// - Add dummy providers
		objs_map.putAll(requiredProvidersMap);

		// - Add this to new predicate set.
		Set<String> generatedProps = new HashSet<>();
		// - Add availability of dummy providers
		for (String t : requiredProvidersMap.keySet()) {
			Set<Obj> providers = requiredProvidersMap.get(t);
			for (Obj p : providers) {
				String prop = generateAvailProp(p.name);
				inits.add(prop);
				generatedProps.add(prop);
				
				Set<String> relatedNumericProps = generateNumericProps(p, numericPropsMap);
				inits.addAll(relatedNumericProps);
			}
		}
		// - Add availability of real providers (which will be removed)
		for (Obj p : removedPoviders) {
			String prop = generateAvailProp(p.name);
			inits.add(prop);
			generatedProps.add(prop);
		}

		List<String> goals = ProblemParser.extractGoals(probPDDL);
		String metric = ProblemParser.parseMetric(probPDDL);

		String newProb = constructNewProb(domainName, inits, goals, metric);
//		System.out.println(newProb);

		// 2. Create new domain from old one
		String newDomain = Utils.read(benchmark + "/domain.pddl");
		// Add new predicates
		newDomain = insertGeneratedProps(newDomain, generatedProps);

		// - For each pair of dummy one and real one, create a selecting action
		Set<String> allGeneratedActs = new HashSet<>();
		for (String type : requiredProvidersMap.keySet()) {
			Set<Obj> requiredObjs = requiredProvidersMap.get(type);
			// Preconditions: both are available
			// Effects: Both are unavailable, set all related prob.
			Set<String> genActs = generateActs(requiredObjs, removedPoviders, relatedPropOfRemovedProviders);
			allGeneratedActs.addAll(genActs);
		}
		newDomain = insertGeneratedActs(allGeneratedActs, newDomain);
		// - Insert new objects as constants
		newDomain = insertGeneratedObjs(objs_map, newDomain);
//		System.out.println(newDomain);

		Utils.write(genInstancesDir.getAbsolutePath() + "/instance-" + i + ".pddl", newProb);
		Utils.write(genInstancesDir.getAbsolutePath() + "/domain-" + i + ".pddl", newDomain);
	}

	private static String generateNumPropTemp(String p, Obj provider) {
		p = p.replace(" " + provider.name + ")", " ???)");
		p = p.replace(" " + provider.name + " ", " ??? ");
		int start = p.lastIndexOf(" ");
		int end = p.lastIndexOf(")");
		String num = p.substring(start, end).trim();
		p = p.replace(num + ")", "0)");
		return p;
	}

	private static Set<String> generateNumericProps(Obj p, Map<String, Set<String>> numericPropsMap) {
		Set<String> result = new HashSet<>();
		Set<String> props = numericPropsMap.get(p.type);
		if (props != null)
			for (String prop : props) {
				prop = prop.replace("???", p.name);
				result.add(prop);
			}
		return result;
	}

	private static String constructNewProb(String domaiName, Set<String> inits, List<String> goals, String metric) {
		String goalsPDDL = "(:goal (and \n";
		for (String g : goals)
			goalsPDDL += "\t" + g + "\n";
		goalsPDDL += "))";
		String initPDDL = "(:init \n";
		for (String i : inits)
			initPDDL += "\t" + i + "\n";
		initPDDL += ")";
		String pddl = "(define (problem test)\n";
		pddl += "(:domain " + domaiName + ")\n";

		pddl += initPDDL + "\n";
		pddl += goalsPDDL + "\n";
		pddl += metric + "\n";
		pddl += ")";
		return pddl;
	}

	private static String insertGeneratedObjs(Map<String, Set<Obj>> objs_map, String newDomain) {
		StringBuffer objs = new StringBuffer("\n\t;;---START GENERATED OBJS----;;\n\t");
		for (String type : objs_map.keySet()) {
			Set<Obj> os = objs_map.get(type);
			if (!os.isEmpty()) {
				for (Obj o : os)
					objs.append(o.name + " ");
				objs.append("- " + type + "\n\t");
			}
		}
		objs.append("\n\t;;---END GENERATED OBJS----;;\n");
		StringBuffer result = new StringBuffer(newDomain);
		int index = result.indexOf("(:constants");
		if (index != -1) {
			index += "(:constants".length();
		} else {
			index = result.indexOf("(:predicates") - 1;
			objs.insert(0, "(:constants \n");
			objs.insert(objs.length(), "\n)\n");
		}
		result.insert(index, objs);
		return result.toString();
	}

	private static String insertGeneratedActs(Set<String> allGeneratedActs, String newDomain) {
		StringBuffer acts = new StringBuffer("\n;;---START GENERATED ACTS----;;\n");
		for (String a : allGeneratedActs) {
			acts.append(a + "\n");
		}
		acts.append("\n;;---END GENERATED ACTS----;;\n");
		StringBuffer result = new StringBuffer(newDomain);
		int index = result.lastIndexOf(")");
		result.insert(index, acts);
		return result.toString();
	}

	private static String generateAvailProp(String name) {
		return "(" + AVAILBLE_PROP_PREFIX + "-" + name + ")";
	}

	private static Set<String> generateActs(Set<Obj> requiredObjs, Set<Obj> removedPoviders,
			Map<Obj, Set<String>> relatedPropOfRemovedProviders) {
		Set<String> result = new HashSet<>();
		for (Obj requiredPro : requiredObjs) {
			for (Obj realPro : removedPoviders) {
				if (requiredPro.type.equals(realPro.type)) {
					String act = generateAct(requiredPro, realPro, relatedPropOfRemovedProviders.get(realPro));
//					System.out.println(act);
//					System.out.println("------------------");
					result.add(act);
				}
			}
		}
		return result;
	}

	private static String generateAct(Obj requiredPro, Obj realPro, Set<String> relatedProps) {
		StringBuffer result = new StringBuffer(
				"(:action " + SELECTING_ACT_PREFIX + "-" + requiredPro.name + "-" + realPro.name + "\n");

		result.append("\t:precondition (and\n");
		result.append("\t\t" + generateAvailProp(requiredPro.name) + "\n");
		result.append("\t\t" + generateAvailProp(realPro.name) + "\n");
		result.append("\t)\n");

		result.append("\t:effect (and\n");
		result.append("\t\t(not " + generateAvailProp(requiredPro.name) + ")\n");
		result.append("\t\t(not " + generateAvailProp(realPro.name) + ")\n");

		for (String prop : relatedProps) {
			String newProp = adjustProp(prop, requiredPro, realPro);
			result.append("\t\t" + newProp + "\n");
		}

		result.append("\t)\n");

		result.append(")");
		return result.toString();
	}

	private static String adjustProp(String prop, Obj replacingPro, Obj pro) {
		String result = prop;
		if (result.contains("(= "))
			result = result.replace("(= ", "(increase  ");
		result = result.replace(" " + pro.name + " ", " " + replacingPro.name + " ");
		result = result.replace(" " + pro.name + ")", " " + replacingPro.name + ")");
		return result;
	}

	private static String insertGeneratedProps(String newDomain, Set<String> generatedProps) {
		StringBuffer insertedProps = new StringBuffer("");
		insertedProps.append("\n\t;;---START GENERATED PROPS----;;\n");
		for (String prop : generatedProps)
			insertedProps.append("\t" + prop + "\n");
		insertedProps.append("\n\t;;---END GENERATED PROPS----;;\n");
		String newPredicates = "(:predicates\n" + insertedProps.toString();
		newDomain = newDomain.replace("(:predicates", newPredicates);
		return newDomain;
	}

	public static Set<String> computeRelatedProps(Collection<String> inits, Obj provider) {
		Set<String> result = new HashSet<>();
		for (String i : inits) {
			if (i.contains(" " + provider.name + " ") || i.contains(" " + provider.name + ")"))
				result.add(i);
		}
		return result;
	}

	private static Map<String, Set<Obj>> mergeProviderMap(Map<String, Set<Obj>> finalProvidersMap,
			Map<String, Set<Obj>> providersMap) {
		for (String type : providersMap.keySet()) {
			Set<Obj> finalSet = finalProvidersMap.get(type);
			if (finalSet == null)
				finalSet = new HashSet<>();
			finalSet.addAll(providersMap.get(type));
			finalProvidersMap.put(type, finalSet);
		}
		return finalProvidersMap;
	}

	public static List<Service> parseDomain(String content) {

		Set<String> actSetText = new HashSet<>();
		int i = 0, j = i + 1;
		while (true) {
			i = content.indexOf("(:action", j);
			if (i == -1)
				break;
			j = Utils.findClosingParen(content.toCharArray(), i);
			if (j <= i)
				break;
			String act = content.substring(i, j + 1);
			actSetText.add(act);
			i = j + 1;
		}

		List<Service> services = new ArrayList<>();
		for (String actTxt : actSetText) {
			Service s = DomainParser.parseService(actTxt);
			services.add(s);
		}
		return services;
	}
}
