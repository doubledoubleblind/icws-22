package analysis;

import java.util.ArrayList;
import java.util.List;

import analysis.domain.service.Predicate;
import analysis.domain.service.Service;

public class Preprocessor {


	public static List<Service> simplify(List<Service> services) {
		List<Service> reducedServices = new ArrayList<>();
		for (Service s : services) {
			Service reducedService = reduceService(s, services);
//			System.out.println(reducedService);
			if (!containsReducedService(reducedServices, reducedService))
				reducedServices.add(reducedService);
		}
//		System.out.println(services.size() + "--" + reducedServices.size());
//		for (Service service : reducedServices) {
//			System.out.println(service);
//		}
		return reducedServices;
	}

	private static boolean containsReducedService(List<Service> services, Service s) {
		for (Service other : services) {
			// TODO: for simplicity, ignore numeric conditions/changes
			if (other.preconds.equals(s.preconds) && other.pEffects.equals(s.pEffects)
					&& other.nEffects.equals(s.nEffects))
				return true;
		}
		return false;
	}

	private static Service reduceService(Service s, List<Service> services) {
		Service result = new Service(s);
		List<Predicate> unchangablePredicates = new ArrayList<>();
		for (Predicate pred : s.preconds) {
			if (!canBeChanged(pred, services, s)) {
				unchangablePredicates.add(pred);
			}
		}
		result.preconds.removeAll(unchangablePredicates);
		return result;
	}

	public static boolean canBeChanged(Predicate pred, List<Service> services, Service s) {
		List<Service> ss = new ArrayList<>(services);
		if (s != null)
			ss.remove(s);
		for (Service other : services) {
//			if (!other.equals(s)) {
			for (Predicate nPred : other.nEffects) {
				if (nPred.compareType(pred)) {
					return true;
				}
			}
//			}
		}
		return false;
	}

}
