package analysis.domain.service.grounding;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import analysis.domain.service.Funct;
import analysis.domain.service.Function;
import analysis.domain.service.NumericChange;
import analysis.domain.service.NumericCondition;
import analysis.domain.service.Predicate;
import analysis.domain.service.Provider;
import analysis.domain.service.Service;
import analysis.domain.service.obj.Obj;
import analysis.restriction.ObjectPropValues;
import analysis.utils.Utils;

public class Grounder {

	public static GroundedFunct symbolicFunctGrounding(Funct pred) {
		GroundedFunct result = null;
		if (pred instanceof Predicate)
			result = new GroundedPredicate(pred);
		else
			result = new GroundedFunction(pred);
		List<Obj> arguments = new ArrayList<Obj>();
		for (Obj variable : pred.paras) {
			Obj groundedObj = createAGroundObj(variable, arguments);
			result.addObjs(groundedObj);
		}
		return result;
	}

	/**
	 * @param groundedObjs list of grounded objs, size = s.paras.size
	 * @param s
	 * @param pred         is a predicate in s
	 * @return
	 */
	public static GroundedPredicate symbolicPredicateGrounding(List<Obj> groundedObjs, Service s, Predicate pred) {
		GroundedPredicate result = new GroundedPredicate(pred);
		if (!pred.paras.isEmpty()) {
			List<Obj> serviceParas = s.paras;
			for (Obj variable : pred.paras) {
				Obj groundedObj = null;
				int index = serviceParas.indexOf(variable);
				if (index == -1 && !variable.name.startsWith("?"))
					groundedObj = variable;
				else
					groundedObj = groundedObjs.get(index);
//				assert(groundedObj!=null);
				result.addObjs(groundedObj);
			}
		}
		return result;
	}

	/**
	 * @param s
	 * @param isARelations
	 * @param pred         is a predicate in s
	 * @return
	 */
	public static GroundedService symbolicServiceGrounding(Service s, GroundedFunct prop,
			Map<String, Set<String>> isARelations) {
		GroundedService gs = new GroundedService(s.name);
		gs.setSymbolicService(s);
		Funct matchedEffectOrChange = findMatchedEffectOrChange(s, prop, isARelations);

		Map<String, Obj> variable_obj = new HashMap<>();
		for (int i = 0; i < matchedEffectOrChange.paras.size(); i++) {
			Obj variable = matchedEffectOrChange.paras.get(i);
			variable_obj.put(variable.toString(), prop.arguments.get(i));
		}

		List<Obj> arguments = new ArrayList<Obj>();
		for (int i = 0; i < s.paras.size(); i++) {
			Obj variable = s.paras.get(i);
			Obj arg = variable_obj.get(variable.toString());
			if (arg == null) {
//				System.out.println("----> CREATING OBJ " + variable + " of " + s.name);
				arg = createAGroundObj(variable, arguments);
			}
			arguments.add(arg);
		}

		gs.arguments = arguments;
		if (!arguments.isEmpty())
			gs.provider = new Provider(arguments.get(0));
		for (Predicate precond : s.preconds) {
			GroundedPredicate p = symbolicPredicateGrounding(arguments, s, precond);
			gs.addPrecond(p);
		}
		for (Predicate eff : s.pEffects) {
			GroundedPredicate p = symbolicPredicateGrounding(arguments, s, eff);
			gs.addPEffect(p);
		}
		for (Predicate eff : s.nEffects) {
			GroundedPredicate p = symbolicPredicateGrounding(arguments, s, eff);
			gs.addNEffect(p);
		}
		for (NumericCondition cond : s.conditions) {
			GroundedNumericCondition c = symbolicNumericGrounding(arguments, s, cond);
			gs.addCondition(c);
		}

		for (NumericChange change : s.changes) {
			GroundedNumericChange c = symbolicNumericGrounding(arguments, s, change);
			gs.addChange(c);
		}

		return gs;
	}

	private static GroundedNumericChange symbolicNumericGrounding(List<Obj> groundedObjs, Service s,
			NumericChange change) {
		GroundedNumericChange result = new GroundedNumericChange();
		String content = change.content;
		if (!change.participants.isEmpty()) {
			List<Obj> serviceParas = s.paras;
			for (Function f : change.participants) {
				GroundedFunction gf = new GroundedFunction(f);
				for (Obj variable : f.paras) {
					int index = serviceParas.indexOf(variable);
					Obj groundedObj = groundedObjs.get(index);
					gf.addObjs(groundedObj);

					content = content.replace(" " + variable.name + " ", " " + groundedObj.name + " ");
					content = content.replace(" " + variable.name + ")", " " + groundedObj.name + ")");
				}
				result.addParticipant(gf);
			}
			result.setContent(content);
		}
		return result;
	}

	private static GroundedNumericCondition symbolicNumericGrounding(List<Obj> groundedObjs, Service s,
			NumericCondition cond) {
		GroundedNumericCondition result = new GroundedNumericCondition();
		String content = cond.content;
		if (!cond.participants.isEmpty()) {
			List<Obj> serviceParas = s.paras;
			for (Function f : cond.participants) {
				GroundedFunction gf = new GroundedFunction(f);
				for (Obj variable : f.paras) {
					int index = serviceParas.indexOf(variable);
					Obj groundedObj = groundedObjs.get(index);
					gf.addObjs(groundedObj);

					content = content.replace(" " + variable.name + " ", " " + groundedObj.name + " ");
					content = content.replace(" " + variable.name + ")", " " + groundedObj.name + ")");
				}
				result.addParticipant(gf);
			}
			result.setContent(content);
		}

		return result;
	}

	private static Obj createAGroundObj(Obj variable, List<Obj> arguments) {
		Obj result = new Obj(variable.type);
		while (true) {
			result.name = variable.type + "-" + Utils.randomNumber(100, 999);
			if (!arguments.contains(result))
				break;
		}
		return result;
	}

	private static Funct findMatchedEffectOrChange(Service s, GroundedFunct prop,
			Map<String, Set<String>> isARelations) {
		if (prop instanceof GroundedPredicate) {
			for (Predicate pred : s.pEffects) {
				if (pred.canBeGroundedTo(prop, isARelations))
					return pred;
			}
		} else {
			for (NumericChange c : s.changes) {
				for (Function f : c.participants) {
					if (f.canBeGroundedTo(prop, isARelations))
						return f;
				}
			}
		}
		return null;
	}

	public static GroundedService symbolicServiceGrounding(Service s, GroundedFunct prop,
			Map<String, Set<String>> isARelations, Map<String, Set<Obj>> givenObjs, Map<String, Set<Obj>> createdObjs) {
		GroundedService gs = new GroundedService(s.name);
		gs.setSymbolicService(s);
		Funct matchedEffectOrChange = findMatchedEffectOrChange(s, prop, isARelations);

		Map<String, Obj> variable_obj = new HashMap<>();
		for (int i = 0; i < matchedEffectOrChange.paras.size(); i++) {
			Obj variable = matchedEffectOrChange.paras.get(i);
			variable_obj.put(variable.toString(), prop.arguments.get(i));
		}

		List<Obj> arguments = new ArrayList<Obj>();
		for (int i = 0; i < s.paras.size(); i++) {
			Obj variable = s.paras.get(i);
			Obj arg = variable_obj.get(variable.toString());
			if (arg == null) {
				if (!canCreateArg(variable.type, givenObjs, createdObjs, isARelations)) {
//					System.out.println("------->HERE: " + variable);
					Set<Obj> createdOnes = createdObjs.get(variable.type);
					arg = Utils.selectAnElm(createdOnes);
				} else {
					arg = createAGroundObj(variable, arguments);
				}

			}
			arguments.add(arg);
		}

		gs.arguments = arguments;
		if (!arguments.isEmpty())
			gs.provider = new Provider(arguments.get(0));
		for (Predicate precond : s.preconds) {
			GroundedPredicate p = symbolicPredicateGrounding(arguments, s, precond);
			gs.addPrecond(p);
		}
		for (Predicate eff : s.pEffects) {
			GroundedPredicate p = symbolicPredicateGrounding(arguments, s, eff);
			gs.addPEffect(p);
		}
		for (Predicate eff : s.nEffects) {
			GroundedPredicate p = symbolicPredicateGrounding(arguments, s, eff);
			gs.addNEffect(p);
		}
		for (NumericCondition cond : s.conditions) {
			GroundedNumericCondition c = symbolicNumericGrounding(arguments, s, cond);
			gs.addCondition(c);
		}

		for (NumericChange change : s.changes) {
			GroundedNumericChange c = symbolicNumericGrounding(arguments, s, change);
			gs.addChange(c);
		}

		return gs;
	}

	private static boolean canCreateArg(String type, Map<String, Set<Obj>> givenObjs, Map<String, Set<Obj>> createdObjs,
			Map<String, Set<String>> isARelations) {

		Set<Obj> createdOnes = createdObjs.get(type);
		if (createdOnes == null)
			return true;
		// Check with the size of created one with the given one, and the child type
		Set<Obj> givenOnes = givenObjs.get(type);
		Set<String> childTypes = findChildTypes(type, isARelations);
		if (givenOnes == null)
			givenOnes = new HashSet<>();
		for (String child : childTypes) {
			Set<Obj> os = givenObjs.get(child);
			if (os != null)
				givenOnes.addAll(os);
		}
		if (createdOnes.size() < givenOnes.size())
			return true;
//		System.out.println(type + " is over-created");
//		System.out.println(givenOnes);
//		System.out.println(createdOnes);
//		System.out.println("_______________");
		return false;
	}

	public static boolean isOverCreated(Map<String, Set<Obj>> createdObjs, Map<String, Set<Obj>> givenObjs,
			Map<String, Set<String>> isARelations) {
		for (String type : createdObjs.keySet()) {
			Set<Obj> createdOnes = createdObjs.get(type);

			// Check with the size of created one with the given one, and the child type
			Set<Obj> givenOnes = givenObjs.get(type);
			Set<String> childTypes = findChildTypes(type, isARelations);
			if (givenOnes == null)
				givenOnes = new HashSet<>();
			for (String child : childTypes) {
				Set<Obj> os = givenObjs.get(child);
				if (os != null)
					givenOnes.addAll(os);
			}
//			System.out.println(type + "--" + childTypes);
//			System.out.println(givenOnes);
//			System.out.println(createdOnes);
//			System.out.println("----------------");
			if (createdOnes.size() > givenOnes.size()) {
				System.out.println(type + " is over-created");
				System.out.println(givenOnes);
				System.out.println(createdOnes);
				System.out.println("_______________");
				return true;
			}
		}
		return false;
	}

	private static Set<String> findChildTypes(String type, Map<String, Set<String>> isARelations) {
		Set<String> result = new HashSet<>();
		for (String child : isARelations.keySet()) {
			if (isARelations.get(child).contains(type)) {
				result.add(child);
			}
		}
		return result;
	}

	// This is for restriction computation
	public static Set<GroundedService> groundByInits(Service s, GroundedFunct prop, Map<String, Set<Obj>> objs_map,
			Funct matchedPrecond, Set<String> unchangablePredNames, Set<String> unchangableFacts,
			ObjectPropValues opv) {

		Map<String, Obj> variable_obj = new HashMap<>();
		for (int i = 0; i < matchedPrecond.paras.size(); i++) {
			Obj variable = matchedPrecond.paras.get(i);
			variable_obj.put(variable.toString(), prop.arguments.get(i));
		}
		List<Obj> partiallyDetArgs = new ArrayList<Obj>();
		Map<Integer, List<Obj>> argCandidatesMap = new HashMap<>();
		for (int i = 0; i < s.paras.size(); i++) {
			Obj variable = s.paras.get(i);
			Obj arg = variable_obj.get(variable.toString());
			if (arg == null) {
				Set<Obj> createdOnes = objs_map.get(variable.type);
				arg = Utils.selectAnElm(createdOnes);
				argCandidatesMap.put(i, new ArrayList<>(createdOnes));
			}
			partiallyDetArgs.add(arg);
		}

		List<List<Obj>> allArgSets = computeAllArgSets(0, partiallyDetArgs, argCandidatesMap, null);
		Set<GroundedService> allGroundedServices = new HashSet<GroundedService>();
		for (List<Obj> argSet : allArgSets) {
			GroundedService gs = new GroundedService(s.name);
			gs.setSymbolicService(s);
			gs.arguments = argSet;
			if (!gs.arguments.isEmpty())
				gs.provider = new Provider(partiallyDetArgs.get(0));
			boolean isValidGS = true;
			for (Predicate precond : s.preconds) {
				GroundedPredicate p = normalGround(gs.arguments, s, precond);
				String pPDDL = p.toPDDL();
				if (p.arguments.contains(opv.getProvider()) && !opv.getAllPossibleProps().contains(pPDDL)) {
//					System.out.println(pPDDL);
					isValidGS = false;
					break;
				}
				if (unchangablePredNames.contains(precond.name) && !unchangableFacts.contains(pPDDL)) {
					isValidGS = false;
					break;
				}
				gs.addPrecond(p);

			}
			if (isValidGS) {
				for (Predicate eff : s.pEffects) {
					GroundedPredicate p = normalGround(gs.arguments, s, eff);
					gs.addPEffect(p);
				}
				for (Predicate eff : s.nEffects) {
					GroundedPredicate p = normalGround(gs.arguments, s, eff);
					gs.addNEffect(p);
				}
				allGroundedServices.add(gs);
			}
		}
//		System.out.println(allGroundedServices.size());
		return allGroundedServices;

	}

	private static GroundedPredicate normalGround(List<Obj> arguments, Service s, Predicate pred) {
		GroundedPredicate p = new GroundedPredicate(pred);
		for (Obj para : pred.paras) {
			int index = s.paras.indexOf(para);
			p.addObjs(arguments.get(index));
		}
		return p;
	}

	private static List<List<Obj>> computeAllArgSets(int i, List<Obj> partiallyDetArgs,
			Map<Integer, List<Obj>> argCandidatesMap, List<List<Obj>> trunk) {
		if (i >= partiallyDetArgs.size())
			return trunk;
		List<Obj> cands = argCandidatesMap.get(i);
		List<List<Obj>> createdTrunk = new ArrayList<List<Obj>>();
		if (cands == null) {
			cands = new ArrayList<Obj>();
			cands.add(partiallyDetArgs.get(i));
		}
		if (trunk == null) {
			for (Obj obj : cands) {
				List<Obj> partialSet = new ArrayList<Obj>();
				partialSet.add(obj);
				createdTrunk.add(partialSet);
			}
		} else {
			for (List<Obj> oldPartialSet : trunk) {
				for (Obj obj : cands) {
					List<Obj> partialSet = new ArrayList<Obj>(oldPartialSet);
					partialSet.add(obj);
					createdTrunk.add(partialSet);
				}
			}
		}
		return computeAllArgSets(i + 1, partiallyDetArgs, argCandidatesMap, createdTrunk);
	}

	private static Funct findMatchedPrecond(Service s, GroundedFunct prop, Map<String, Set<String>> isARelations) {
		if (prop instanceof GroundedPredicate) {
			for (Predicate pred : s.preconds) {
				if (pred.canBeGroundedTo(prop, isARelations))
					return pred;
			}
		}
		return null;
	}
}
