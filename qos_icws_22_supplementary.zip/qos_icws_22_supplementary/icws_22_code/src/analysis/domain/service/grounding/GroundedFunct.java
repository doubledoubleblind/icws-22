package analysis.domain.service.grounding;

import java.util.ArrayList;
import java.util.List;

import analysis.domain.service.Funct;
import analysis.domain.service.Provider;
import analysis.domain.service.obj.Obj;

public class GroundedFunct {
	public Funct funct;
	public List<Obj> arguments;

	/**
	 * For reused analysis
	 */
	public List<GroundedService> producingServices;
	int index;

	/**
	 * For preference option. The provider, which provides a service conditioned on
	 * the grounded funct, would be the preferred one.
	 */
	public Provider preferedProvider;

	public void printLayer() {
		System.out.println("PROP: \t\t" + this);
		if (producingServices.isEmpty())
			System.out.println("NO PRODUCING SERVICE.");
		for (GroundedService s : producingServices) {
			System.out.println(s);
		}
		System.out.println("------------------------\n\n");
		for (GroundedService s : producingServices) {
			s.printLayer();
		}
	}

	public GroundedFunct(Funct funct) {
		this.funct = funct;
		arguments = new ArrayList<>();
		producingServices = new ArrayList<>();
	}

	public void addObjs(Obj o) {
		this.arguments.add(o);
	}

	@Override
	public String toString() {
		return funct.name + "-" + arguments.toString();
	}

	@Override
	public boolean equals(Object obj) {
		return toString().equalsIgnoreCase(obj.toString());
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	public void setIndex(int index) {
		this.index = index;
	}
}
