package analysis.domain.service.grounding;

import analysis.domain.service.Funct;
import analysis.domain.service.obj.Obj;

public class GroundedPredicate extends GroundedFunct {

	public GroundedPredicate(Funct funct) {
		super(funct);
	}
//	public Predicate predicate;

	public String toPDDL() {
		String result = "(" + this.funct.name;
		for (Obj obj : arguments)
			result += " " + obj.name;
		result += ")";
		return result;
	}

}
