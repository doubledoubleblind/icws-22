package analysis.action;

public class Proposition {

}
