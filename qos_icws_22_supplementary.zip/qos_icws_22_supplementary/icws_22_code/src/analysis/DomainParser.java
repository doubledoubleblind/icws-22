package analysis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import analysis.domain.service.Funct;
import analysis.domain.service.Function;
import analysis.domain.service.NumericChange;
import analysis.domain.service.NumericCondition;
import analysis.domain.service.Predicate;
import analysis.domain.service.Service;
import analysis.domain.service.obj.Obj;
import analysis.utils.Utils;

public class DomainParser {

	public static Predicate parsePredicate(String predicateTxt) {
//		(loc ?p - pt ?l - location)
		predicateTxt = predicateTxt.trim();
		if (predicateTxt.isBlank())
			return null;
		predicateTxt = predicateTxt.trim().replace("(", "").replace(")", "");
		int endingName = predicateTxt.indexOf(" ");
		String name = predicateTxt.substring(0, endingName).trim();

		Predicate result = new Predicate(name);

		String[] parts = predicateTxt.split(" ");
		Set<String> currParaSet = new HashSet<>();
		String currType = "";
		for (int i = 0; i < parts.length; i++) {
			if (parts[i].equals("-")) {
				currType = parts[i + 1];
				for (String pn : currParaSet) {
					Obj variable = new Obj(currType, pn);
					result.addPara(variable);
				}
				currParaSet = new HashSet<>();
			} else if (parts[i].startsWith("?")) {
				currParaSet.add(parts[i]);
			}
		}
		return result;
	}

	public static List<Service> parseFile(String file) {

		String content = Utils.readPDDL(file);
		parseConstants(content);

		Set<String> actSetText = new HashSet<>();
		int i = 0, j = i + 1;
		while (true) {
			i = content.indexOf("(:action", j);
			if (i == -1)
				break;
			j = Utils.findClosingParen(content.toCharArray(), i);
			if (j <= i)
				break;
			String act = content.substring(i, j + 1);
			actSetText.add(act);
			i = j + 1;
		}

		List<Service> services = new ArrayList<>();
		for (String actTxt : actSetText) {
			Service s = parseService(actTxt);
			services.add(s);
		}
		return services;
	}

	public static List<Obj> parseConstants(String content) {
		CONSTANTS = new ArrayList<>();
		int start = content.indexOf("(:constants") + "(:constants".length();
		int end = Utils.findClosingParen(content.toCharArray(), start);
		String constText = content.substring(start, end).trim().toLowerCase();
		String[] lines = constText.split("\n");
		for (String l : lines) {
			l = l.trim().toLowerCase();
			if (!l.isEmpty()) {
				String[] parts = l.split(" - ");
				if (parts.length == 2) {
					String type = parts[1];
					String[] names = parts[0].split(" ");
					for (String name : names) {
						Obj o = new Obj(type, name);
						CONSTANTS.add(o);
					}
				}
			}
		}
		return CONSTANTS;
	}

	public static Service parseService(String actTxt) {
		int i, j;
		i = actTxt.indexOf("(:action") + "(:action".length();
		j = actTxt.indexOf("\n", i);
		String name = actTxt.substring(i, j).trim();
		Service s = new Service(name);

		i = actTxt.indexOf(":parameters");
		i = actTxt.indexOf("(", i);
		j = Utils.findClosingParen(actTxt.toCharArray(), i);
		String paras = actTxt.substring(i, j + 1);
		s.setParas(paras);

		i = actTxt.indexOf(":precondition");
		i = actTxt.indexOf("(", i);
		j = Utils.findClosingParen(actTxt.toCharArray(), i);
		String precondTxt = actTxt.substring(i + "(and".length(), j).trim();

		i = j = 0;
		while (true) {
			i = precondTxt.indexOf("(", j);
			if (i == -1)
				break;
			j = Utils.findClosingParen(precondTxt.toCharArray(), i) + 1;
			String p = precondTxt.substring(i, j);

			if (p.contains(">") || p.contains("<") || p.contains("=")) {
				NumericCondition cond = new NumericCondition(p, s.paras);
				s.addCond(cond);
			} else {
				Predicate pre = new Predicate(p.trim(), s.paras);
				s.addPrecond(pre);
			}
		}

		i = actTxt.indexOf(":effect");
		i = actTxt.indexOf("(", i);
		j = Utils.findClosingParen(actTxt.toCharArray(), i);
		String effectTxt = actTxt.substring(i + "(and".length(), j).trim();

		i = j = 0;
		while (true) {
			i = effectTxt.indexOf("(", j);
			if (i == -1)
				break;
			j = Utils.findClosingParen(effectTxt.toCharArray(), i) + 1;
			String e = effectTxt.substring(i, j).trim();
			if (e.startsWith("(decrease ") || e.startsWith("(increase ") || e.startsWith("(assign ")) {
				NumericChange change = new NumericChange(e, s.paras);
				s.addChange(change);
			} else {
				if (!e.startsWith("(not ")) {
					Predicate ep = new Predicate(e, s.paras);
					s.addPEffect(ep);
				} else {
					e = e.replace("(not ", "");
					e.substring(0, e.length() - 1);
					Predicate ep = new Predicate(e, s.paras);
					s.addNEffect(ep);
				}
			}
		}
		return s;
	}

	public static List<Service> parseDomain(String content) {

		Set<String> actSetText = new HashSet<>();
		int i = 0, j = i + 1;
		while (true) {
			i = content.indexOf("(:action", j);
			if (i == -1)
				break;
			j = Utils.findClosingParen(content.toCharArray(), i);
			if (j <= i)
				break;
			String act = content.substring(i, j + 1);
			actSetText.add(act);
			i = j + 1;
		}

		List<Service> services = new ArrayList<>();
		for (String actTxt : actSetText) {
			Service s = parseService(actTxt);
			services.add(s);
		}
		return services;
	}

	public static Set<Funct> allPredicates(List<Service> services) {
		Set<Funct> result = new HashSet<>();
		for (Service s : services) {
			for (Predicate p : s.pEffects)
				if (!isAddedFunct(p, result))
					result.add(p);

			for (Predicate p : s.preconds)
				if (!isAddedFunct(p, result))
					result.add(p);

			for (Function p : s.functs)
				if (!isAddedFunct(p, result))
					result.add(p);
		}
		return result;
	}

	private static boolean isAddedFunct(Funct p, Set<Funct> result) {
		for (Funct funct : result) {
			if (p.getSignature().equals(funct.getSignature()))
				return true;
		}
		return false;
	}

	/**
	 * For type, child is a parent
	 * 
	 * @param file
	 * @return
	 */
	public static Map<String, Set<String>> parseTypes(String file) {
		Map<String, Set<String>> relations = new HashMap<>();
		String content = Utils.readPDDL(file);
		int start = content.indexOf("(:types") + "(:types".length();
		int end = Utils.findClosingParen(content.toCharArray(), start);
		String typeText = content.substring(start, end).trim();
//		System.out.println(typeText);
		String[] lines = typeText.split("\n");
		for (String l : lines) {
			l = l.trim().toLowerCase();
			if (!l.isEmpty()) {
				String[] parts = l.split(" - ");
				if (parts.length == 2) {
					String parent = parts[1];
					String[] children = parts[0].split(" ");
					for (String child : children) {
						Set<String> parents = new HashSet<>();
						parents.add(parent);
						relations.put(child, parents);
					}
				}
			}
		}

		// Refine
		while (true) {
			boolean isChanged = false;
			for (String child : relations.keySet()) {
				Set<String> parents = relations.get(child);
				Set<String> othersParents = new HashSet<>(parents);
				for (String p : parents) {
					Set<String> grandParents = relations.get(p);
					if (grandParents != null)
						othersParents.addAll(grandParents);
				}
				if (!othersParents.equals(parents)) {
					relations.put(child, othersParents);
					isChanged = true;
				}
			}
			if (!isChanged)
				break;

		}
		return relations;
	}

	public static List<Obj> CONSTANTS = new ArrayList<Obj>();

//	public static List<Service> parseFile(String file) {
//	
//		String content = Utils.readPDDL(file);
//	
//		List<String> actSetText = new ArrayList<>();
//		int i = 0, j = i + 1;
//		while (true) {
//			i = content.indexOf("(:action", j);
//			if (i == -1)
//				break;
//			j = Utils.findClosingParen(content.toCharArray(), i);
//			if (j <= i)
//				break;
//			String act = content.substring(i, j + 1);
//			actSetText.add(act);
//			i = j + 1;
//		}
//	
//		List<Service> services = new ArrayList<>();
//		for (String actTxt : actSetText) {
//			Service s = DomainParser.parseService(actTxt);
//			services.add(s);
//		}
//		return services;
//	}
//
//	public static Service parseService(String actTxt) {
//		int i, j;
//		i = actTxt.indexOf("(:action") + "(:action".length();
//		j = actTxt.indexOf("\n", i);
//		String name = actTxt.substring(i, j).trim();
//		Service s = new Service(name);
//	
//		i = actTxt.indexOf(":parameters");
//		i = actTxt.indexOf("(", i);
//		j = Utils.findClosingParen(actTxt.toCharArray(), i);
//		String paras = actTxt.substring(i, j + 1);
//		s.setParas(paras);
//	
//		i = actTxt.indexOf(":precondition");
//		i = actTxt.indexOf("(", i);
//		j = Utils.findClosingParen(actTxt.toCharArray(), i);
//		String precondTxt = actTxt.substring(i + "(and".length(), j).trim();
//	
//		i = j = 0;
//		while (true) {
//			i = precondTxt.indexOf("(", j);
//			if (i == -1)
//				break;
//			j = Utils.findClosingParen(precondTxt.toCharArray(), i) + 1;
//			String p = precondTxt.substring(i, j);
//	
//			if (p.contains(">") || p.contains("<") || p.contains("=")) {
//				NumericCondition cond = new NumericCondition(p, s.paras);
//				s.addCond(cond);
//			} else {
//				Predicate pre = new Predicate(p.trim(), s.paras);
//				s.addPrecond(pre);
//			}
//		}
//	
//		i = actTxt.indexOf(":effect");
//		i = actTxt.indexOf("(", i);
//		j = Utils.findClosingParen(actTxt.toCharArray(), i);
//		String effectTxt = actTxt.substring(i + "(and".length(), j).trim();
//	
//		i = j = 0;
//		while (true) {
//			i = effectTxt.indexOf("(", j);
//			if (i == -1)
//				break;
//			j = Utils.findClosingParen(effectTxt.toCharArray(), i) + 1;
//			String e = effectTxt.substring(i, j).trim();
//			if (e.startsWith("(decrease ") || e.startsWith("(increase ") || e.startsWith("(assign ")) {
//				NumericChange change = new NumericChange(e, s.paras);
//				s.addChange(change);
//			} else {
//				if (!e.startsWith("(not ")) {
//					Predicate ep = new Predicate(e, s.paras);
//					s.addPEffect(ep);
//				} else {
//					e = e.replace("(not ", "");
//					e.substring(0, e.length() - 1);
//					Predicate ep = new Predicate(e, s.paras);
//					s.addNEffect(ep);
//				}
//			}
//		}
//		return s;
//	}
}
