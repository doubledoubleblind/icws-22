This is our implementation for our reformulation.
Please try: ReducedProblemCreator