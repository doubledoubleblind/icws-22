Our benchmark domains: 	icws_22_benchmarks
Our implementation: 	icws_22_code