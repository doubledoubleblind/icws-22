package analysis;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import analysis.domain.service.Provider;
import analysis.domain.service.Service;
import analysis.domain.service.grounding.GroundedFunct;
import analysis.domain.service.grounding.GroundedFunction;
import analysis.domain.service.grounding.GroundedNumericChange;
import analysis.domain.service.grounding.GroundedNumericCondition;
import analysis.domain.service.grounding.GroundedService;
import analysis.domain.service.grounding.Grounder;
import analysis.domain.service.obj.Obj;

public class DomainAnalyzer {
	public static Set<GroundedService> consideredServices = new HashSet<GroundedService>();
	public static Set<GroundedFunct> consideredFuncts = new HashSet<>();
	public static Set<Provider> consideredProviders = new HashSet<>();
	public static Set<GroundedFunct> unchangableProps = new HashSet<>();

	public static void reset() {
		consideredServices = new HashSet<GroundedService>();
		consideredFuncts = new HashSet<>();
		consideredProviders = new HashSet<>();
		unchangableProps = new HashSet<>();
		DomainParser.CONSTANTS = new ArrayList<>();
	}

	// 2nd version, where given sets of objects are given
	public static void analyze(List<Service> services, GroundedFunct p, int counter, Map<String, Set<Obj>> givenObjs,
			Map<String, Set<Obj>> createdObjs, Map<String, Set<String>> isARelations) {
		if (createdObjs == null)
			createdObjs = new HashMap<>();
		if (counter < 0)
			return;

		if (isConsidered(p, consideredFuncts))
			return;
		consideredFuncts.add(p);
		Set<GroundedService> producingServices = new HashSet<GroundedService>();
		p.setIndex(counter);
		for (Service s : services) {
			if (s.canProduce(p, isARelations)) {
				GroundedService gs = Grounder.symbolicServiceGrounding(s, p, isARelations, givenObjs, createdObjs);
				if (gs != null) {
					if (Config.PREFERENCE) {
						if (p.preferedProvider != null && p.preferedProvider.compareType(gs.provider))
							gs.provider = p.preferedProvider;
					}
					producingServices.add(gs);
					gs.setIndex(counter);
					p.producingServices.add(gs);
				} 
			}
		}
		if (producingServices.isEmpty())
			unchangableProps.add(p);

		if (!producingServices.isEmpty()) {
			consideredServices.addAll(producingServices);
			for (GroundedService gs : producingServices) {
				List<GroundedFunct> conditions = new ArrayList<>(gs.preconds);
				for (GroundedNumericCondition c : gs.conditions) {
					for (GroundedFunct f : c.participants)
						conditions.add(f);
				}
				gs.conditioningProps.addAll(conditions);

				for (GroundedNumericChange c : gs.changes) {
					Set<GroundedFunct> dependingFuncts = findAllDependingFunct(c, p);
					conditions.addAll(dependingFuncts);
				}
				Map<String, Set<Obj>> newCreatedObjs = computeCreatedObjs(gs, createdObjs);
				if (Config.DEBUG) {
					System.out.println("-----------------");
					System.out.println(">>>" + gs.getIndex() + " -- " + p);
					System.out.println(gs);
				}
				for (GroundedFunct f : conditions) {
					f.preferedProvider = gs.provider;
					analyze(services, f, counter - 1, givenObjs, newCreatedObjs, isARelations);
				}
			}
		}

	}

	private static Map<String, Set<Obj>> computeCreatedObjs(GroundedService gs, Map<String, Set<Obj>> createdObjs) {
		Map<String, Set<Obj>> result = new HashMap<String, Set<Obj>>(createdObjs);
		for (Obj arg : gs.arguments) {
			Set<Obj> objs = result.get(arg.type);
			if (objs == null)
				objs = new HashSet<>();
			objs.add(arg);
			result.put(arg.type, objs);
		}

		return result;
	}

	public static void analyze(List<Service> services, GroundedFunct p, int counter,
			Map<String, Set<String>> isARelations) {
		if (counter-- == 0)
			return;
//		System.out.println("===============");
//		System.out.println(">>>" + p);
		if (isConsidered(p, consideredFuncts))
			return;
		consideredFuncts.add(p);
		Set<GroundedService> producingServices = new HashSet<GroundedService>();
		p.setIndex(counter);
		for (Service s : services) {
			if (s.canProduce(p, isARelations)) {
				GroundedService gs = Grounder.symbolicServiceGrounding(s, p, isARelations);
				if (gs != null) {
					producingServices.add(gs);
					gs.setIndex(counter);
//				System.out.println("-->" + gs);
					p.producingServices.add(gs);
				}
			}
		}
		if (producingServices.isEmpty())
			unchangableProps.add(p);

		consideredServices.addAll(producingServices);
		if (!producingServices.isEmpty()) {
			for (GroundedService gs : producingServices) {
				List<GroundedFunct> conditions = new ArrayList<>(gs.preconds);
				for (GroundedNumericCondition c : gs.conditions) {
					for (GroundedFunct f : c.participants)
						conditions.add(f);
				}
				gs.conditioningProps.addAll(conditions);

				for (GroundedNumericChange c : gs.changes) {
					Set<GroundedFunct> dependingFuncts = findAllDependingFunct(c, p);
					conditions.addAll(dependingFuncts);
				}
				for (GroundedFunct f : conditions) {
					analyze(services, f, counter, isARelations);
				}
			}
		}
	}

	/**
	 * If a property p of a provider typed t cannot be changed, then for each
	 * provider with a value of p, a pari p-t can be considered as a type.
	 * unchangable props can affect the computation.
	 * 
	 * @return
	 */
	public static Map<String, Set<Obj>> computeProviders() {
		Map<String, Set<Obj>> providerCounters = new HashMap<>();
		Set<Provider> allProviders = DomainAnalyzer.extractProviders(consideredServices);
		for (Provider provider : allProviders) {
			Set<GroundedService> providedServices = findProvidedServices(provider, consideredServices);
			Set<GroundedFunct> allCondUnchangableProp = new HashSet<>();
			for (GroundedService gs : providedServices) {
				Set<GroundedFunct> conditionendUnchangableProp = findConditionedUnchangableProps(provider, gs,
						unchangableProps);
				allCondUnchangableProp.addAll(conditionendUnchangableProp);
			}

			Set<Obj> providers = null;
			/*
			 * If a property p of a provider typed t cannot be changed, then for each
			 * provider with a value of p, a pari p-t can be considered as a type.
			 * unchangable props can affect the computation.
			 */
			if (!allCondUnchangableProp.isEmpty()) {
				List<String> functs = new ArrayList<>();
				for (GroundedFunct gf : allCondUnchangableProp)
					functs.add(gf.funct.toString());
				Collections.sort(functs);
				String combinedType = provider.type + "***" + functs.toString();
				providers = new HashSet<Obj>();
				providers.add(provider);
				providerCounters.put(combinedType, providers);
			} else {
				providers = providerCounters.get(provider.type);
				if (providers == null)
					providers = new HashSet<Obj>();
				providers.add(provider);
				providerCounters.put(provider.type, providers);
//				System.out.println(provider);
			}

		}
		return providerCounters;
	}

	private static Set<GroundedFunct> findConditionedUnchangableProps(Provider p, GroundedService gs,
			Set<GroundedFunct> unchangableProperties) {
		Set<GroundedFunct> pUnchangableProps = new HashSet<>(gs.preconds);
		pUnchangableProps.retainAll(unchangableProperties);

		Set<GroundedFunct> ps = new HashSet<>();
		for (GroundedFunct prop : pUnchangableProps) {
			if (prop.arguments.contains(p))
				ps.add(prop);
		}
		return ps;
	}

	public static Set<GroundedService> getConsideredServices() {
		return consideredServices;
	}

	private static Set<GroundedFunct> findAllDependingFunct(GroundedNumericChange c, GroundedFunct p) {
		Set<GroundedFunct> result = new HashSet<GroundedFunct>();
		if (!c.participants.isEmpty()) {
			GroundedFunction f = c.participants.get(0);
			if (f.equals(f)) {
				for (int i = 1; i < c.participants.size(); i++)
					result.add(c.participants.get(i));
			}
		}
		return result;
	}

	private static boolean isConsidered(GroundedFunct p, Set<GroundedFunct> checkedProps) {
		for (GroundedFunct checkedProp : checkedProps) {
			if (p.funct.name.equals(checkedProp.funct.name)) {
				if (p.arguments.isEmpty())
					return true;
				if (p.arguments.get(0).equals(checkedProp.arguments.get(0))) {
					return true;
				}
			}
		}
		return false;
	}

	public static Service getServiceByName(String name, Collection<Service> sers) {
		for (Service service : sers) {
			if (service.name.equalsIgnoreCase(name))
				return service;
		}
		return null;
	}

	public static Set<Provider> extractProviders(Set<GroundedService> consideredServices) {
		Set<Provider> allProviders = new HashSet<>();
		for (GroundedService gs : consideredServices) {
			Provider p = gs.provider;
			allProviders.add(p);
		}
		return allProviders;
	}

	public static Set<GroundedService> findProvidedServices(Provider provider,
			Set<GroundedService> consideredServices) {
		Set<GroundedService> result = new HashSet<>();
		for (GroundedService s : consideredServices) {
			if (s.provider.equals(provider))
				result.add(s);
		}
		return result;
	}

}
