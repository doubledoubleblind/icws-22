package analysis;

public interface Config {
	public static Boolean DEBUG = false;
	public static boolean SIMPLIFY = true;
	public static int MAX_DETH = 30;
	public static boolean PREFERENCE = false;
	public static boolean REUSED = true;
}
