package analysis.restriction;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import analysis.Preprocessor;
import analysis.domain.service.Predicate;
import analysis.domain.service.Service;

/**
 */
public class EnvironmentalObjectsIdentifier {


	static Set<String> extractUnchangableFacts(List<Service> services, Set<String> inits) {
		Set<Predicate> allPreds = new HashSet<Predicate>();
		for (Service s : services)
			allPreds.addAll(s.preconds);
		Set<String> unChangablePredNames = new HashSet<>();
		for (Predicate pred : allPreds) {
			if (!Preprocessor.canBeChanged(pred, services, null)) 
				unChangablePredNames.add(pred.name);
		}
		Set<String> unchangableFacts = new HashSet<>();
		for (String f : inits) {
			if (isAnUnchangableFact(f, unChangablePredNames)) {
				unchangableFacts.add(f);
			}
		}
		return unchangableFacts;
	}
	
	static Set<String> extractUnchangablePredNames(List<Service> services) {
		Set<Predicate> allPreds = new HashSet<Predicate>();
		for (Service s : services)
			allPreds.addAll(s.preconds);
		Set<String> unChangablePredNames = new HashSet<>();
		for (Predicate pred : allPreds) {
			if (!Preprocessor.canBeChanged(pred, services, null)) 
				unChangablePredNames.add(pred.name);
		}
		return unChangablePredNames;
	}

	private static boolean isAnUnchangableFact(String f, Set<String> unChangablePredNames) {
		for (String n : unChangablePredNames) {
			if (f.contains("(" + n + " "))
				return true;
		}
		return false;
	}

}
