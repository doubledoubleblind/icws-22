package analysis;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import analysis.domain.service.Predicate;
import analysis.domain.service.grounding.GroundedFunct;
import analysis.domain.service.obj.Obj;
import analysis.utils.Utils;

public class ProblemParser {
	public static Set<String> INIT_ALL = new HashSet<>();


	public static String convertObjToDummyAct(Obj obj) {
		if (obj.properties.isEmpty())
			return "";
		String result = "(:action dummy-" + obj.type + "-" + obj.name + "\n";
		result += "\t:parameters (?dummy - " + obj.type + " )\n";
		result += "\t:precondition  (and " + "(unselected-" + obj.type + " ?dummy" + " )" + " )\n";
		result += "\t:effect (and \n" + "\t\t(not (unselected-" + obj.type + " ?dummy" + " ))\n";
		String effs = "";
		for (String ef : obj.properties) {
			if (ef.contains("(= "))
				ef = ef.replace("(= ", "(assign ");
			ef = ef.replace(" " + obj.name, " ?dummy");
			effs += "\t\t" + ef + "\n";
		}
		result += effs;
		result += "\t)\n";
		result += " )\n";

		return result;
	}

	// Each prop is in a line
	public static Set<Obj> parseObjInit(String prob, Set<Obj> objs) {
		int start = prob.indexOf("(:init");
		if (start == -1)
			return null;
		int end = Utils.findClosingParen(prob.toCharArray(), start);
		if (end == -1)
			return null;
		String[] lines = prob.substring(start + "(:init".length(), end).trim().split("\n");
		for (String line : lines) {
			line = line.trim();
			if (!line.isEmpty()) {

				String name = null;
				String[] parts = null;
				if (!line.contains("=")) {
					parts = line.split(" ");
				} else {
					int i = line.indexOf("(= (") + "(= (".length();
					int j = Utils.findClosingParen(line.toCharArray(), i);
					parts = line.substring(i, j).split(" ");
				}
				if (parts.length > 1)
					name = parts[1].replace(")", "").trim();
				if (name != null) {
					Obj o = getObjByName(name, objs);
					objs.remove(o);
					o.addProperty(line);
					objs.add(o);
				} else {
					INIT_ALL.add(line);
				}
			}
		}
		return objs;
	}

	// Each prop is in a line
	public static Set<String> parseInit(String prob) {
		Set<String> inits = new HashSet<>();
		int start = prob.indexOf("(:init");
		if (start == -1)
			return null;
		int end = Utils.findClosingParen(prob.toCharArray(), start);
		if (end == -1)
			return null;
		String[] lines = prob.substring(start + "(:init".length(), end).trim().split("\n");
//		System.out.println(prob.substring(start + "(:init".length(), end).trim());
		for (String line : lines) {
			line = line.trim();
			if (!line.isEmpty())
				inits.add(line);
		}
		return inits;
	}

	public static Obj getObjByName(String name, Collection<Obj> objs) {
		for (Obj o : objs) {
			if (o.name.equalsIgnoreCase(name))
				return o;
		}
		return null;
	}

	// Each type is in a line
	public static Map<String, Set<Obj>> parseObjs(String prob) {
		Map<String, Set<Obj>> result = new HashMap<>();
		int start = prob.indexOf("(:objects");
		if (start == -1)
			return null;
		int end = Utils.findClosingParen(prob.toCharArray(), start);
		if (end == -1)
			return null;
		String[] lines = prob.substring(start + "(:objects".length(), end).trim().split("\n");
		for (String line : lines) {
			line = line.trim().toLowerCase();
			if (!line.isEmpty()) {
				String[] parts = line.split(" ");
				String type = parts[parts.length - 1];
				Set<Obj> objs = result.get(type);
				if (objs == null)
					objs = new HashSet<>();
				for (int i = 0; i < parts.length - 2; i++) {
					String name = parts[i].trim();
					if (!name.isEmpty()) {
						Obj o = new Obj(type, name);
						objs.add(o);
					}
				}
				result.put(type, objs);
			}
		}
		return result;
	}

	public static Map<String, Set<Obj>> parseObjsV1(String prob) {
		Map<String, Set<Obj>> result = new HashMap<>();
		int start = prob.indexOf("(:objects");
		if (start == -1)
			return null;
		int end = Utils.findClosingParen(prob.toCharArray(), start);
		if (end == -1)
			return null;
		String objsTxt = prob.substring(start + "(:objects".length(), end).trim().toLowerCase();
		objsTxt = objsTxt.replace("\n", " ");
//		System.out.println(objsTxt);
		start = end = 0;
		while (true) {
			end = objsTxt.indexOf(" - ", start);
			if (end == -1)
				break;
			String currObjs = objsTxt.substring(start, end).trim();
			start = objsTxt.indexOf(" ", end + " - ".length() + 1);
			if (start == -1) {
//				break;
				start = objsTxt.length();
			}
			String type = objsTxt.substring(end + " - ".length(), start).trim();
//			System.out.println(currObjs);
//			System.out.println(type);
//			System.out.println("-------------");
			Set<Obj> objs = result.get(type);
			if (objs == null)
				objs = new HashSet<>();
			String parts[] = currObjs.split(" ");
			for (int i = 0; i < parts.length; i++) {
				String name = parts[i];
				if (!name.trim().isEmpty()) {
					Obj o = new Obj(type, name);
					objs.add(o);
				}
			}
			result.put(type, objs);
		}
		return result;
	}

	public static List<GroundedFunct> extractGoals(String prob, Map<String, Set<Obj>> objs_map) {
		Set<Obj> objs = new HashSet<>();
		for (String type : objs_map.keySet())
			objs.addAll(objs_map.get(type));
		objs.addAll(DomainParser.CONSTANTS);

		List<GroundedFunct> goals = new ArrayList<>();
		int start = prob.indexOf("(:goal");
		if (start < 0)
			return null;
		start = prob.indexOf("(and", start + "(:goal".length()) + "(and".length();
		int end = Utils.findClosingParen(prob.toCharArray(), start);
		String goalsTxt = prob.substring(start, end - 1).trim();
		String[] lines = goalsTxt.split("\n");
		for (String l : lines) {
			l = l.trim();
			GroundedFunct g = parseProposition(l, objs);
//			System.out.println(l);
//			System.out.println(g);
//			System.out.println("----------");
			goals.add(g);
		}
		return goals;
	}

	public static List<Predicate> extractGoalPredicates(String prob, Map<String, Set<Obj>> objs_map) {
		Set<Obj> objs = new HashSet<>();
		for (String type : objs_map.keySet())
			objs.addAll(objs_map.get(type));
		objs.addAll(DomainParser.CONSTANTS);

		List<Predicate> goals = new ArrayList<>();
		int start = prob.indexOf("(:goal");
		if (start < 0)
			return null;
		start = prob.indexOf("(and", start + "(:goal".length()) + "(and".length();
		int end = Utils.findClosingParen(prob.toCharArray(), start);
		String goalsTxt = prob.substring(start, end - 1).trim();
		String[] lines = goalsTxt.split("\n");
		for (String l : lines) {
			l = l.trim();
			Predicate g = parsePredicate(l, objs);
			goals.add(g);
		}
		return goals;
	}

	public static List<String> extractGoals(String prob) {
		List<String> goals = new ArrayList<>();
		int start = prob.indexOf("(:goal");
		if (start < 0)
			return null;
		start = prob.indexOf("(and", start + "(:goal".length()) + "(and".length();
		int end = Utils.findClosingParen(prob.toCharArray(), start);
		String goalsTxt = prob.substring(start, end - 1).trim();
		String[] lines = goalsTxt.split("\n");
		for (String l : lines) {
			goals.add(l.trim());
		}
		return goals;
	}

	public static GroundedFunct parseProposition(String propTxt, Collection<Obj> objs) {
//		(loc ?p - pt ?l - location)
		propTxt = propTxt.trim();
		if (propTxt.isEmpty())
			return null;
		propTxt = propTxt.trim().replace("(", "").replace(")", "");
		int endingName = propTxt.indexOf(" ");
		String name = propTxt.substring(0, endingName).trim();

		Predicate pred = new Predicate(name);
		GroundedFunct result = new GroundedFunct(pred);

		String[] parts = propTxt.split(" ");
		if (parts.length > 1)
			for (int i = 1; i < parts.length; i++) {
				Obj o = getObjByName(parts[i], objs);
				result.addObjs(o);
				Obj para = new Obj(o.type, "?" + o.name);
				result.funct.addPara(para);
			}
		return result;
	}

	public static Predicate parsePredicate(String propTxt, Collection<Obj> objs) {
//		(loc ?p - pt ?l - location)
		propTxt = propTxt.trim();
		if (propTxt.isEmpty())
			return null;
		propTxt = propTxt.trim().replace("(", "").replace(")", "");
		int endingName = propTxt.indexOf(" ");
		String name = propTxt.substring(0, endingName).trim();

		Predicate pred = new Predicate(name);
		String[] parts = propTxt.split(" ");
		if (parts.length > 1)
			for (int i = 1; i < parts.length; i++) {
				Obj o = getObjByName(parts[i], objs);
				Obj para = new Obj(o.type, "?" + o.name);
				pred.addPara(para);
			}
		return pred;
	}

	public static String parseMetric(String prob) {
		prob = prob.toLowerCase();
		int start = prob.indexOf("(:metric");
		if (start == -1)
			return "";
		int end = Utils.findClosingParen(prob.toCharArray(), start + "(:metric".length());
		String metric = prob.substring(start, end + 1).trim();
		return metric;
	}
}
