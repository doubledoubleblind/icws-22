package analysis.test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import analysis.DomainParser;
import analysis.domain.service.Funct;
import analysis.domain.service.Function;
import analysis.domain.service.Predicate;
import analysis.domain.service.Service;
import analysis.domain.service.obj.Obj;
import analysis.utils.Utils;

public class DomainParserTester {



	public static Predicate parsePredicate(String predicateTxt) {
//		(loc ?p - pt ?l - location)
		predicateTxt = predicateTxt.trim();
		if (predicateTxt.isBlank())
			return null;
		predicateTxt = predicateTxt.trim().replace("(", "").replace(")", "");
		int endingName = predicateTxt.indexOf(" ");
		String name = predicateTxt.substring(0, endingName).trim();

		Predicate result = new Predicate(name);

		String[] parts = predicateTxt.split(" ");
		Set<String> currParaSet = new HashSet<>();
		String currType = "";
		for (int i = 0; i < parts.length; i++) {
			if (parts[i].equals("-")) {
				currType = parts[i + 1];
				for (String pn : currParaSet) {
					Obj variable = new Obj(currType, pn);
					result.addPara(variable);
				}
				currParaSet = new HashSet<>();
			} else if (parts[i].startsWith("?")) {
				currParaSet.add(parts[i]);
			}
		}
		return result;
	}

	public static List<Service> parseDomain(String content) {

		Set<String> actSetText = new HashSet<>();
		int i = 0, j = i + 1;
		while (true) {
			i = content.indexOf("(:action", j);
			if (i == -1)
				break;
			j = Utils.findClosingParen(content.toCharArray(), i);
			if (j <= i)
				break;
			String act = content.substring(i, j + 1);
			actSetText.add(act);
			i = j + 1;
		}

		List<Service> services = new ArrayList<>();
		for (String actTxt : actSetText) {
			Service s = DomainParser.parseService(actTxt);
			services.add(s);
		}
		return services;
	}

	public static Set<Funct> allPredicates(List<Service> services) {
		Set<Funct> result = new HashSet<>();
		for (Service s : services) {
			for (Predicate p : s.pEffects)
				if (!isAddedFunct(p, result))
					result.add(p);

			for (Predicate p : s.preconds)
				if (!isAddedFunct(p, result))
					result.add(p);

			for (Function p : s.functs)
				if (!isAddedFunct(p, result))
					result.add(p);
		}
		return result;
	}

	private static boolean isAddedFunct(Funct p, Set<Funct> result) {
		for (Funct funct : result) {
			if (p.getSignature().equals(funct.getSignature()))
				return true;
		}
		return false;
	}
}
