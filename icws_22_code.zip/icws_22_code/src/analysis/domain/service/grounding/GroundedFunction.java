package analysis.domain.service.grounding;

import analysis.domain.service.Funct;

public class GroundedFunction extends GroundedFunct{

	public GroundedFunction(Funct funct) {
		super(funct);
	}
//	public Function function;
}
